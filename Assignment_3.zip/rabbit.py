# Prints ASCII ART of rabbits
# Lulama Lingela
# 24 February 2023

print("""
(\\\               (\/)      
( '')    (\_/)   (.. )   //)
O(")(") (\\'.'/) (")(")O (" ) 
        (")_(")        ()()o
""")