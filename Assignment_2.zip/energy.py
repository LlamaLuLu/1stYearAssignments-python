# program to input values m and c, then calculate and output value of energy quantity
# Lulama Lingela
# 19 February 2023

m = int(input("Enter the value of m: "))
c = int(input("\nEnter the value of c: "))

energy = m * (c ** 2)

print(f"\nThe value of energy, E, is: {energy}")